export class BookCategory {
    categoryId : number;
    categoryName: string;
}
