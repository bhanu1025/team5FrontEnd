import { CartConstants } from './cart-constants';

describe('CartConstants', () => {
  it('should create an instance', () => {
    expect(new CartConstants()).toBeTruthy();
  });
});
