export class CustomerInformation {
    customerId : number;
    emailAddress : string;
    fullName : string;
    password : string;
    phoneNumber : string;
    address : string;
    city : string;
    zipCode : number;
    country : string;
    registerDate : Date;
}
