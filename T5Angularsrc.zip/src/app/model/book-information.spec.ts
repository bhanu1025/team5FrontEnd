import { BookInformation } from './book-information';

describe('BookInformation', () => {
  it('should create an instance', () => {
    expect(new BookInformation()).toBeTruthy();
  });
});
