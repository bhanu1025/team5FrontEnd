import { CartInformation } from './cart-information';

describe('CartInformation', () => {
  it('should create an instance', () => {
    expect(new CartInformation()).toBeTruthy();
  });
});
