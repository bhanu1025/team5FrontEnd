import { OrderInformation } from './order-information';

describe('OrderInformation', () => {
  it('should create an instance', () => {
    expect(new OrderInformation()).toBeTruthy();
  });
});
