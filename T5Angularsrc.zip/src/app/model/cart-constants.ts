export class CartConstants {

    public static SPRING_WEB="http://localhost:8082/bookstore/";

    public static VIEW_BOOKS_URL = CartConstants.SPRING_WEB+"viewallbooks"
    public static ADD_BOOK_CART_URL = CartConstants.SPRING_WEB+"addbooktocart";
    public static UPDATE_CART_URL= CartConstants.SPRING_WEB+"update";

}
